n="anagram"
m="nagaram"
if len(n)==len(m) and sorted(n)==sorted(m):
    print("true")
else:
    print("false")